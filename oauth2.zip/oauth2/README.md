1)import this project into eclipse
2) Browser : http://localhost:8080/oauth/authorize?client_id=clientapp&response_type=code&scope=read_profile_info
3) Enter credentials as tufail and 123456
4) OAuth Approval will come
5) Please accept Approve
6) It will go to localhost:9090/customer.
7) But, check the URL , you will get the authorization code
http://localhost:9090/customer?code=92iVAl
8) Open postman

method - POST
http://localhost:8080/oauth/token

Headers = 

Content-Type  : application/x-www-form-urlencoded
Authorization : Basic Y2xpZW50YXBwOjEyMzQ1Ng==

Body =
x-www.form-urlencoded
grant_type : authorization_code
code : code which you got above
redirect_url : http://localhost:9001/product

You will get the token :

{
    "access_token": "dcc51ce2-c233-4e83-be2d-ca534c6d0fac",
    "token_type": "bearer",
    "refresh_token": "29c6e14c-c33e-4164-a1a6-a3c9e8fba581",
    "expires_in": 49999,
    "scope": "read_profile_info"
}
=======================

GET

http://localhost:8080/pms/userDetails

Header

Authorization : 	Bearer <Token what you have recived above>